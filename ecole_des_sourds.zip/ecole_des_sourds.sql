-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:3306
-- Généré le : mar. 24 jan. 2023 à 14:10
-- Version du serveur : 8.0.30
-- Version de PHP : 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `ecole_des_sourds`
--

-- --------------------------------------------------------

--
-- Structure de la table `admins`
--

CREATE TABLE `admins` (
  `id` int NOT NULL,
  `identifiant` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `pwd` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `admins`
--

INSERT INTO `admins` (`id`, `identifiant`, `pwd`) VALUES
(1, 'Jean98', 'Admin'),
(2, 'Jean98', 'Admin');

-- --------------------------------------------------------

--
-- Structure de la table `article`
--

CREATE TABLE `article` (
  `id` int NOT NULL,
  `article_title` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `article_file` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `article_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `article`
--

INSERT INTO `article` (`id`, `article_title`, `article_file`, `article_description`, `created_date`) VALUES
(1, 'La pédagogie au centre des sourds', './asset/Ressources/IMG-63cc647f076e41.18540915.png', '\r\nAu primaire, la pédagogie est basée sur l\'apprentissage par l\'expérience. Les enfants apprennent en jouant, en expérimentant et en explorant leur environnement. Les enseignants utilisent des activités pratiques pour aider les élèves à comprendre les concepts, comme des jeux, et des projets créatifs.\r\n\r\nAu collège, la pédagogie est  plus axée sur la théorie. Les enseignants donnent des cours magistraux et utilisent des livres de textes pour transmettre les connaissances. Les étudiants sont également encouragés à travailler en groupe et à participer à des discussions pour développer leur pensée critique et leur capacité à communiquer efficacement.\r\n\r\nNous utilisons aussi des méthodes pédagogiques alternatives telles que la pédagogie Montessori, qui met l\'accent sur l\'autonomie de l\'enfant et la découverte par soi-même, ou la pédagogie Freinet, qui met l\'accent sur l\'expérience de l\'élève et la participation active de celui-ci dans le processus d\'apprentissage.\r\n\r\nEn fin de compte, le choix de la méthode pédagogique dépend des objectifs de l\'école et des besoins des élèves. Il est important que les enseignants soient formés pour utiliser différentes méthodes et soient en mesure de s\'adapter aux besoins de chaque élève pour garantir un apprentissage efficace.', '2023-01-20 23:00:00'),
(2, 'Apprentissage facile au enfant sourds', './asset/Ressources/IMG-63cc67408ba095.79854998.jpg', 'Il est important de fournir une instruction efficace aux enfants sourds ou malentendants, car cela peut avoir un impact significatif sur leur développement et leur réussite scolaire. \r\nL\'apprentissage facilité pour les enfants sourds peut inclure l\'utilisation de méthodes visuelles pour transmettre des informations, comme l\'utilisation de dessins, de photos, de vidéos et de diagrammes. Les enseignants utilisent des outils technologiques tels que des tableaux interactifs, des ordinateurs et des applications pour soutenir l\'apprentissage. Nous combinons surtout la langue des signes avec l\'oral pour une instruction bilingue.\r\nLes enseignants  utilisent également des techniques d\'enseignement différenciées pour s\'adapter aux besoins individuels des élèves sourds ou malentendants. Par exemple, ils peuvent donner des instructions écrites en plus de celles orales, ou utiliser des tactiques de mise en situation pour aider les élèves à comprendre les concepts.', '2023-01-20 23:00:00'),
(3, 'La langue des signes', './asset/Ressources/IMG-63cc69996fdd75.65975963.jpg', 'La langue des signes est un système complet de communication visuelle et gestuelle utilisé par les personnes sourdes ou malentendantes pour communiquer avec les autres. \r\nLa langue des signes est souvent considérée comme une langue à part entière, avec ses propres règles syntaxiques et grammaticales. Elle utilise des gestes, des expressions faciales et des mouvements du corps pour transmettre des idées et des concepts. Les signes sont souvent basés sur des mouvements naturels, tels que les gestes que l\'on utilise pour décrire des objets ou des actions dans l\'espace, et peuvent varier considérablement d\'une langue des signes à l\'autre.\r\nC\'est une langue à part entière qui nécessite une reconnaissance et une valorisation pour les personnes qui l\'utilisent. Il est important de sensibiliser les gens aux besoins des personnes sourdes et de favoriser l\'inclusion et l\'égalité pour tous pour briser les barrières de communication et d\'accès à l\'éducation et à l\'emploi.', '2023-01-20 23:00:00');

-- --------------------------------------------------------

--
-- Structure de la table `candidature`
--

CREATE TABLE `candidature` (
  `id` int NOT NULL,
  `lastname` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `firstname` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `email` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `classe` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `motivation` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `candidature`
--

INSERT INTO `candidature` (`id`, `lastname`, `firstname`, `email`, `classe`, `motivation`) VALUES
(11, 'Tom', 'tam', 'er@fe.cv', '4ieme', 'assidut'),
(12, 'Tom', 'tam', 'er@fe.cv', '4ieme', 'assidut'),
(13, 'Adjaho', 'Serge', 'aymaradjaho@gmail.com', '5ieme', 'erreur'),
(14, 'elon', 'musk', 'elonmusk@', '', ''),
(15, 'Bill', 'Clinton', 'Billclinton@youyou.fr', '3iem', 'J\'aime étudié');

-- --------------------------------------------------------

--
-- Structure de la table `formation`
--

CREATE TABLE `formation` (
  `id` int NOT NULL,
  `formation_title` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `formation_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `formation_file` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `formation`
--

INSERT INTO `formation` (`id`, `formation_title`, `formation_description`, `formation_file`) VALUES
(11, 'Le tissage', 'Les cours de tissage sont généralement dispensés par des artisans expérimentés qui partagent leur savoir-faire avec les élèves. Les participants peuvent apprendre à utiliser différents types de métiers à tisser, comme les métiers à tisser manuels ou les métiers à tisser à bras. Ils peuvent également apprendre à utiliser différents types de fils, comme la laine, le coton ou le lin, pour créer des textures et des motifs uniques.\r\n\r\nLes cours de tissage peuvent être adaptés à différents niveaux, des débutants aux plus expérimentés. Les élèves peuvent apprendre à créer des tissages simples, comme des tissages en plain-pied, ou des tissages plus complexes, comme des tissages en damier ou en taffetas. Les cours peuvent également inclure des projets spécifiques, comme la création d\'une écharpe ou d\'un tapis.\r\n\r\nEn plus d\'apprendre les techniques de tissage, les élèves peuvent également découvrir l\'histoire et la culture du tissage dans différentes régions du monde. Ils peuvent apprendre à identifier les différents types de motifs traditionnels et à comprendre leur signification culturelle.\r\n\r\nEn résumé, la formation en tissage est un moyen passionnant de découvrir les techniques de tissage à la main, de créer des pièces uniques et de s\'imprégner de l\'histoire et de la culture du tissage. C\'est une activité créative qui peut être pratiquée à tous les niveaux et qui permet de développer sa patience et sa dextérité.\r\n\r\n\r\n\r\n', './asset/Ressources/IMG-63ce23a5a4a845.98590180.jpg');

-- --------------------------------------------------------

--
-- Structure de la table `images`
--

CREATE TABLE `images` (
  `id` int NOT NULL,
  `url_source` text NOT NULL,
  `admin_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structure de la table `parrainage`
--

CREATE TABLE `parrainage` (
  `id` int NOT NULL,
  `lastname` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `firstname` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `email` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `telephone` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `msg` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `parrainage`
--

INSERT INTO `parrainage` (`id`, `lastname`, `firstname`, `email`, `telephone`, `msg`) VALUES
(27, 'hillary', 'clinton', 'hila@your.com', '23334423', 'je souhaite parrainer un enfant\r\n        ');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `article`
--
ALTER TABLE `article`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `candidature`
--
ALTER TABLE `candidature`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `formation`
--
ALTER TABLE `formation`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `images`
--
ALTER TABLE `images`
  ADD KEY `admin_id` (`admin_id`);

--
-- Index pour la table `parrainage`
--
ALTER TABLE `parrainage`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `article`
--
ALTER TABLE `article`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `candidature`
--
ALTER TABLE `candidature`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT pour la table `formation`
--
ALTER TABLE `formation`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT pour la table `parrainage`
--
ALTER TABLE `parrainage`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `images`
--
ALTER TABLE `images`
  ADD CONSTRAINT `images_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
